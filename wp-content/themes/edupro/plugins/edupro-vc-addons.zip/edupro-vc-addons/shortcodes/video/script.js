jQuery( function ( $ ) {
	'use strict';

	$( '.popup-video' ).magnificPopup( {
		type: 'iframe',
		mainClass: 'mfp-fade'
	} );
} );