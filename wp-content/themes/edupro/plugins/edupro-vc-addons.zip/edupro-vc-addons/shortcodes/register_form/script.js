jQuery( function ( $ ) {
	'use strict';
	
} );